﻿namespace JX48WK_Beadando_Webshop
{
    partial class termekekForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.termek_novenyDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.novenykategoriaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.termek_novenyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.termekFormExitButton = new System.Windows.Forms.Button();
            this.termekBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.termek_novenyDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenykategoriaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.termek_novenyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.termekBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // termek_novenyDataGridView
            // 
            this.termek_novenyDataGridView.AllowUserToAddRows = false;
            this.termek_novenyDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.termek_novenyDataGridView.AutoGenerateColumns = false;
            this.termek_novenyDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.termek_novenyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.termek_novenyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.termek_novenyDataGridView.DataSource = this.termek_novenyBindingSource;
            this.termek_novenyDataGridView.Location = new System.Drawing.Point(0, 0);
            this.termek_novenyDataGridView.Name = "termek_novenyDataGridView";
            this.termek_novenyDataGridView.Size = new System.Drawing.Size(546, 409);
            this.termek_novenyDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "noveny_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "noveny_id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "noveny_nev";
            this.dataGridViewTextBoxColumn2.HeaderText = "Növény név";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "noveny_latin";
            this.dataGridViewTextBoxColumn3.HeaderText = "Latin név";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "noveny_ar";
            this.dataGridViewTextBoxColumn4.HeaderText = "Ár (tároló nélkül)";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "kat_id";
            this.dataGridViewTextBoxColumn5.DataSource = this.novenykategoriaBindingSource;
            this.dataGridViewTextBoxColumn5.DisplayMember = "kat_nev";
            this.dataGridViewTextBoxColumn5.HeaderText = "Kategória";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn5.ValueMember = "kat_id";
            // 
            // novenykategoriaBindingSource
            // 
            this.novenykategoriaBindingSource.DataSource = typeof(JX48WK_Beadando_Webshop.Noveny_kategoria);
            // 
            // termek_novenyBindingSource
            // 
            this.termek_novenyBindingSource.DataSource = typeof(JX48WK_Beadando_Webshop.Termek_noveny);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.button1.Location = new System.Drawing.Point(8, 415);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 31);
            this.button1.TabIndex = 2;
            this.button1.Text = "Új felvétel";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // termekFormExitButton
            // 
            this.termekFormExitButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.termekFormExitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.termekFormExitButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.termekFormExitButton.FlatAppearance.BorderSize = 2;
            this.termekFormExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.termekFormExitButton.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termekFormExitButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.termekFormExitButton.Location = new System.Drawing.Point(462, 415);
            this.termekFormExitButton.Name = "termekFormExitButton";
            this.termekFormExitButton.Size = new System.Drawing.Size(75, 31);
            this.termekFormExitButton.TabIndex = 3;
            this.termekFormExitButton.Text = "Kilépés";
            this.termekFormExitButton.UseVisualStyleBackColor = false;
            this.termekFormExitButton.Click += new System.EventHandler(this.termekFormExitButton_Click);
            // 
            // termekBindingSource
            // 
            this.termekBindingSource.DataSource = typeof(JX48WK_Beadando_Webshop.Termek);
            // 
            // termekekForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(235)))), ((int)(((byte)(168)))));
            this.ClientSize = new System.Drawing.Size(545, 450);
            this.Controls.Add(this.termekFormExitButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.termek_novenyDataGridView);
            this.Name = "termekekForm";
            this.Text = "termekekForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.termekekForm_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.termek_novenyDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenykategoriaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.termek_novenyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.termekBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource termek_novenyBindingSource;
        private System.Windows.Forms.BindingSource novenykategoriaBindingSource;
        private System.Windows.Forms.BindingSource termekBindingSource;
        private System.Windows.Forms.DataGridView termek_novenyDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button termekFormExitButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn5;
    }
}