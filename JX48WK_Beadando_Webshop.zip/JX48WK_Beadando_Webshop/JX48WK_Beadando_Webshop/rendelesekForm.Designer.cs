﻿namespace JX48WK_Beadando_Webshop
{
    partial class rendelesekForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rendelesekKilepesButton = new System.Windows.Forms.Button();
            this.rendelesekFormEmailTextBox = new System.Windows.Forms.TextBox();
            this.rendelesekFormListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rendelesekFormListBox2 = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rendelesFormDataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ujRendelesButton = new System.Windows.Forms.Button();
            this.rendelesFormAddRendeles = new System.Windows.Forms.Button();
            this.rendelesekFormListBox3 = new System.Windows.Forms.ListBox();
            this.rendelesFormAddTermek = new System.Windows.Forms.Button();
            this.rendelesFormRemoveTermek = new System.Windows.Forms.Button();
            this.rendelesekFormTermekSumTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.addTerrakottaCheckBox = new System.Windows.Forms.CheckBox();
            this.addMuanyagCheckBox = new System.Windows.Forms.CheckBox();
            this.addSzinesCheckBox = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.rendelesFormRemoveRendeles = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.iranyLabel = new System.Windows.Forms.Label();
            this.cimLabel = new System.Windows.Forms.Label();
            this.szallModLabel = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.szamlaCegLabel = new System.Windows.Forms.Label();
            this.szamlaIranyLabel = new System.Windows.Forms.Label();
            this.szamlaCimLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ujRendelesDatumTextBox = new System.Windows.Forms.MaskedTextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.addMennyisegTextBox = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.rendelesFormDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // rendelesekKilepesButton
            // 
            this.rendelesekKilepesButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.rendelesekKilepesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.rendelesekKilepesButton.CausesValidation = false;
            this.rendelesekKilepesButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rendelesekKilepesButton.FlatAppearance.BorderSize = 2;
            this.rendelesekKilepesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rendelesekKilepesButton.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rendelesekKilepesButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesekKilepesButton.Location = new System.Drawing.Point(479, 614);
            this.rendelesekKilepesButton.Name = "rendelesekKilepesButton";
            this.rendelesekKilepesButton.Size = new System.Drawing.Size(151, 27);
            this.rendelesekKilepesButton.TabIndex = 0;
            this.rendelesekKilepesButton.Text = "Kilépés";
            this.rendelesekKilepesButton.UseVisualStyleBackColor = false;
            this.rendelesekKilepesButton.Click += new System.EventHandler(this.rendelesekKilepesButton_Click);
            // 
            // rendelesekFormEmailTextBox
            // 
            this.rendelesekFormEmailTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.rendelesekFormEmailTextBox.Location = new System.Drawing.Point(12, 45);
            this.rendelesekFormEmailTextBox.Name = "rendelesekFormEmailTextBox";
            this.rendelesekFormEmailTextBox.Size = new System.Drawing.Size(154, 20);
            this.rendelesekFormEmailTextBox.TabIndex = 2;
            this.rendelesekFormEmailTextBox.TextChanged += new System.EventHandler(this.rendelesekFormEmailTextBox_TextChanged);
            // 
            // rendelesekFormListBox
            // 
            this.rendelesekFormListBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.rendelesekFormListBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesekFormListBox.FormattingEnabled = true;
            this.rendelesekFormListBox.Location = new System.Drawing.Point(12, 84);
            this.rendelesekFormListBox.Name = "rendelesekFormListBox";
            this.rendelesekFormListBox.Size = new System.Drawing.Size(154, 381);
            this.rendelesekFormListBox.TabIndex = 3;
            this.rendelesekFormListBox.SelectedIndexChanged += new System.EventHandler(this.rendelesekFormListBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Szűrés (e-mail):";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "E-mail:";
            // 
            // rendelesekFormListBox2
            // 
            this.rendelesekFormListBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.rendelesekFormListBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesekFormListBox2.FormattingEnabled = true;
            this.rendelesekFormListBox2.Location = new System.Drawing.Point(172, 84);
            this.rendelesekFormListBox2.Name = "rendelesekFormListBox2";
            this.rendelesekFormListBox2.Size = new System.Drawing.Size(136, 316);
            this.rendelesekFormListBox2.TabIndex = 6;
            this.rendelesekFormListBox2.SelectedIndexChanged += new System.EventHandler(this.rendelesekFormListBox2_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(172, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Rendelések:";
            // 
            // rendelesFormDataGridView
            // 
            this.rendelesFormDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rendelesFormDataGridView.AutoGenerateColumns = false;
            this.rendelesFormDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesFormDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rendelesFormDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.rendelesFormDataGridView.DataSource = this.bindingSource1;
            this.rendelesFormDataGridView.Location = new System.Drawing.Point(314, 84);
            this.rendelesFormDataGridView.Name = "rendelesFormDataGridView";
            this.rendelesFormDataGridView.Size = new System.Drawing.Size(546, 381);
            this.rendelesFormDataGridView.TabIndex = 8;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Növény";
            this.Column1.HeaderText = "Növény";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Kategória";
            this.Column2.HeaderText = "Növény kategória";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Tároló";
            this.Column3.HeaderText = "Tároló";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Ár";
            this.Column4.HeaderText = "Ár";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "Mennyiség";
            this.Column5.HeaderText = "Mennyiség";
            this.Column5.Name = "Column5";
            // 
            // ujRendelesButton
            // 
            this.ujRendelesButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ujRendelesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.ujRendelesButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.ujRendelesButton.FlatAppearance.BorderSize = 2;
            this.ujRendelesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ujRendelesButton.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ujRendelesButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.ujRendelesButton.Location = new System.Drawing.Point(479, 19);
            this.ujRendelesButton.Name = "ujRendelesButton";
            this.ujRendelesButton.Size = new System.Drawing.Size(151, 46);
            this.ujRendelesButton.TabIndex = 9;
            this.ujRendelesButton.Text = "Új ügyfél és rendelés";
            this.ujRendelesButton.UseVisualStyleBackColor = false;
            this.ujRendelesButton.Click += new System.EventHandler(this.ujRendelesButton_Click);
            // 
            // rendelesFormAddRendeles
            // 
            this.rendelesFormAddRendeles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rendelesFormAddRendeles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.rendelesFormAddRendeles.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rendelesFormAddRendeles.FlatAppearance.BorderSize = 2;
            this.rendelesFormAddRendeles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rendelesFormAddRendeles.Font = new System.Drawing.Font("Constantia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rendelesFormAddRendeles.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesFormAddRendeles.Location = new System.Drawing.Point(172, 432);
            this.rendelesFormAddRendeles.Name = "rendelesFormAddRendeles";
            this.rendelesFormAddRendeles.Size = new System.Drawing.Size(40, 33);
            this.rendelesFormAddRendeles.TabIndex = 10;
            this.rendelesFormAddRendeles.Text = "+";
            this.rendelesFormAddRendeles.UseVisualStyleBackColor = false;
            this.rendelesFormAddRendeles.Click += new System.EventHandler(this.rendelesFormAddRendeles_Click);
            // 
            // rendelesekFormListBox3
            // 
            this.rendelesekFormListBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rendelesekFormListBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesekFormListBox3.FormattingEnabled = true;
            this.rendelesekFormListBox3.Location = new System.Drawing.Point(937, 84);
            this.rendelesekFormListBox3.Name = "rendelesekFormListBox3";
            this.rendelesekFormListBox3.Size = new System.Drawing.Size(142, 381);
            this.rendelesekFormListBox3.TabIndex = 12;
            // 
            // rendelesFormAddTermek
            // 
            this.rendelesFormAddTermek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rendelesFormAddTermek.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.rendelesFormAddTermek.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rendelesFormAddTermek.FlatAppearance.BorderSize = 2;
            this.rendelesFormAddTermek.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rendelesFormAddTermek.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rendelesFormAddTermek.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesFormAddTermek.Location = new System.Drawing.Point(878, 208);
            this.rendelesFormAddTermek.Name = "rendelesFormAddTermek";
            this.rendelesFormAddTermek.Size = new System.Drawing.Size(40, 33);
            this.rendelesFormAddTermek.TabIndex = 13;
            this.rendelesFormAddTermek.Text = "+";
            this.rendelesFormAddTermek.UseVisualStyleBackColor = false;
            this.rendelesFormAddTermek.Click += new System.EventHandler(this.rendelesFormAddTermek_Click);
            // 
            // rendelesFormRemoveTermek
            // 
            this.rendelesFormRemoveTermek.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rendelesFormRemoveTermek.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.rendelesFormRemoveTermek.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rendelesFormRemoveTermek.FlatAppearance.BorderSize = 2;
            this.rendelesFormRemoveTermek.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rendelesFormRemoveTermek.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rendelesFormRemoveTermek.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesFormRemoveTermek.Location = new System.Drawing.Point(878, 253);
            this.rendelesFormRemoveTermek.Name = "rendelesFormRemoveTermek";
            this.rendelesFormRemoveTermek.Size = new System.Drawing.Size(40, 33);
            this.rendelesFormRemoveTermek.TabIndex = 14;
            this.rendelesFormRemoveTermek.Text = "-";
            this.rendelesFormRemoveTermek.UseVisualStyleBackColor = false;
            this.rendelesFormRemoveTermek.Click += new System.EventHandler(this.rendelesFormRemoveTermek_Click);
            // 
            // rendelesekFormTermekSumTextBox
            // 
            this.rendelesekFormTermekSumTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.rendelesekFormTermekSumTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesekFormTermekSumTextBox.Location = new System.Drawing.Point(758, 471);
            this.rendelesekFormTermekSumTextBox.Name = "rendelesekFormTermekSumTextBox";
            this.rendelesekFormTermekSumTextBox.ReadOnly = true;
            this.rendelesekFormTermekSumTextBox.Size = new System.Drawing.Size(100, 20);
            this.rendelesekFormTermekSumTextBox.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(687, 474);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Összesen:";
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox2.Location = new System.Drawing.Point(937, 45);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(142, 20);
            this.textBox2.TabIndex = 17;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // addTerrakottaCheckBox
            // 
            this.addTerrakottaCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.addTerrakottaCheckBox.AutoSize = true;
            this.addTerrakottaCheckBox.Checked = true;
            this.addTerrakottaCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.addTerrakottaCheckBox.Location = new System.Drawing.Point(937, 481);
            this.addTerrakottaCheckBox.Name = "addTerrakottaCheckBox";
            this.addTerrakottaCheckBox.Size = new System.Drawing.Size(75, 17);
            this.addTerrakottaCheckBox.TabIndex = 19;
            this.addTerrakottaCheckBox.Text = "Terrakotta";
            this.addTerrakottaCheckBox.UseVisualStyleBackColor = true;
            this.addTerrakottaCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.addTerrakottaCheckBox_MouseClick);
            // 
            // addMuanyagCheckBox
            // 
            this.addMuanyagCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.addMuanyagCheckBox.AutoSize = true;
            this.addMuanyagCheckBox.Location = new System.Drawing.Point(937, 504);
            this.addMuanyagCheckBox.Name = "addMuanyagCheckBox";
            this.addMuanyagCheckBox.Size = new System.Drawing.Size(70, 17);
            this.addMuanyagCheckBox.TabIndex = 20;
            this.addMuanyagCheckBox.Text = "Műanyag";
            this.addMuanyagCheckBox.UseVisualStyleBackColor = true;
            this.addMuanyagCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.addMuanyagCheckBox_MouseClick);
            // 
            // addSzinesCheckBox
            // 
            this.addSzinesCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.addSzinesCheckBox.AutoSize = true;
            this.addSzinesCheckBox.Location = new System.Drawing.Point(937, 527);
            this.addSzinesCheckBox.Name = "addSzinesCheckBox";
            this.addSzinesCheckBox.Size = new System.Drawing.Size(91, 17);
            this.addSzinesCheckBox.TabIndex = 21;
            this.addSzinesCheckBox.Text = "Színes kaspó";
            this.addSzinesCheckBox.UseVisualStyleBackColor = true;
            this.addSzinesCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.addSzinesCheckBox_MouseClick);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1030, 485);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Mennyiség:";
            // 
            // rendelesFormRemoveRendeles
            // 
            this.rendelesFormRemoveRendeles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rendelesFormRemoveRendeles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.rendelesFormRemoveRendeles.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rendelesFormRemoveRendeles.FlatAppearance.BorderSize = 2;
            this.rendelesFormRemoveRendeles.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rendelesFormRemoveRendeles.Font = new System.Drawing.Font("Constantia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rendelesFormRemoveRendeles.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesFormRemoveRendeles.Location = new System.Drawing.Point(268, 432);
            this.rendelesFormRemoveRendeles.Name = "rendelesFormRemoveRendeles";
            this.rendelesFormRemoveRendeles.Size = new System.Drawing.Size(40, 33);
            this.rendelesFormRemoveRendeles.TabIndex = 23;
            this.rendelesFormRemoveRendeles.Text = "-";
            this.rendelesFormRemoveRendeles.UseVisualStyleBackColor = false;
            this.rendelesFormRemoveRendeles.Click += new System.EventHandler(this.rendelesFormRemoveRendeles_Click);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(934, 68);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Termék:";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(934, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 13);
            this.label7.TabIndex = 25;
            this.label7.Text = "Szűrés (termék):";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 13);
            this.label8.TabIndex = 26;
            this.label8.Text = "Irányítószám:";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(52, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Cím:";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 13);
            this.label10.TabIndex = 28;
            this.label10.Text = "Szállítási mód:";
            // 
            // iranyLabel
            // 
            this.iranyLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.iranyLabel.AutoSize = true;
            this.iranyLabel.Location = new System.Drawing.Point(83, 8);
            this.iranyLabel.Name = "iranyLabel";
            this.iranyLabel.Size = new System.Drawing.Size(41, 13);
            this.iranyLabel.TabIndex = 29;
            this.iranyLabel.Text = "label11";
            // 
            // cimLabel
            // 
            this.cimLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cimLabel.AutoSize = true;
            this.cimLabel.Location = new System.Drawing.Point(80, 40);
            this.cimLabel.Name = "cimLabel";
            this.cimLabel.Size = new System.Drawing.Size(41, 13);
            this.cimLabel.TabIndex = 30;
            this.cimLabel.Text = "label12";
            // 
            // szallModLabel
            // 
            this.szallModLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.szallModLabel.AutoSize = true;
            this.szallModLabel.Location = new System.Drawing.Point(83, 74);
            this.szallModLabel.Name = "szallModLabel";
            this.szallModLabel.Size = new System.Drawing.Size(41, 13);
            this.szallModLabel.TabIndex = 31;
            this.szallModLabel.Text = "label13";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.richTextBox1.Location = new System.Drawing.Point(504, 505);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(171, 89);
            this.richTextBox1.TabIndex = 32;
            this.richTextBox1.Text = "";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(501, 474);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 13);
            this.label11.TabIndex = 33;
            this.label11.Text = "Megjegyzés:";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(13, 474);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 13);
            this.label12.TabIndex = 34;
            this.label12.Text = "Szállítási cím";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(287, 474);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 13);
            this.label13.TabIndex = 35;
            this.label13.Text = "Számlázási cím";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(318, 8);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 13);
            this.label14.TabIndex = 36;
            this.label14.Text = "Cégnév:";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(295, 40);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 13);
            this.label15.TabIndex = 37;
            this.label15.Text = "Irányítószám:";
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(336, 71);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 13);
            this.label16.TabIndex = 38;
            this.label16.Text = "Cím:";
            // 
            // szamlaCegLabel
            // 
            this.szamlaCegLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.szamlaCegLabel.AutoSize = true;
            this.szamlaCegLabel.Location = new System.Drawing.Point(371, 8);
            this.szamlaCegLabel.Name = "szamlaCegLabel";
            this.szamlaCegLabel.Size = new System.Drawing.Size(41, 13);
            this.szamlaCegLabel.TabIndex = 39;
            this.szamlaCegLabel.Text = "label17";
            // 
            // szamlaIranyLabel
            // 
            this.szamlaIranyLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.szamlaIranyLabel.AutoSize = true;
            this.szamlaIranyLabel.Location = new System.Drawing.Point(371, 40);
            this.szamlaIranyLabel.Name = "szamlaIranyLabel";
            this.szamlaIranyLabel.Size = new System.Drawing.Size(41, 13);
            this.szamlaIranyLabel.TabIndex = 40;
            this.szamlaIranyLabel.Text = "label18";
            // 
            // szamlaCimLabel
            // 
            this.szamlaCimLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.szamlaCimLabel.AutoSize = true;
            this.szamlaCimLabel.Location = new System.Drawing.Point(371, 71);
            this.szamlaCimLabel.Name = "szamlaCimLabel";
            this.szamlaCimLabel.Size = new System.Drawing.Size(41, 13);
            this.szamlaCimLabel.TabIndex = 41;
            this.szamlaCimLabel.Text = "label19";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.szamlaCimLabel);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.szamlaIranyLabel);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.szamlaCegLabel);
            this.panel1.Controls.Add(this.iranyLabel);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.cimLabel);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.szallModLabel);
            this.panel1.Location = new System.Drawing.Point(16, 505);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(460, 93);
            this.panel1.TabIndex = 42;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // ujRendelesDatumTextBox
            // 
            this.ujRendelesDatumTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ujRendelesDatumTextBox.Location = new System.Drawing.Point(172, 406);
            this.ujRendelesDatumTextBox.Name = "ujRendelesDatumTextBox";
            this.ujRendelesDatumTextBox.Size = new System.Drawing.Size(136, 20);
            this.ujRendelesDatumTextBox.TabIndex = 43;
            this.ujRendelesDatumTextBox.TypeValidationCompleted += new System.Windows.Forms.TypeValidationEventHandler(this.ujRendelesDatumTextBox_TypeValidationCompleted);
            // 
            // addMennyisegTextBox
            // 
            this.addMennyisegTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.addMennyisegTextBox.Location = new System.Drawing.Point(1033, 502);
            this.addMennyisegTextBox.Name = "addMennyisegTextBox";
            this.addMennyisegTextBox.Size = new System.Drawing.Size(51, 20);
            this.addMennyisegTextBox.TabIndex = 44;
            this.addMennyisegTextBox.Text = "1";
            // 
            // rendelesekForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(235)))), ((int)(((byte)(168)))));
            this.ClientSize = new System.Drawing.Size(1096, 653);
            this.Controls.Add(this.addMennyisegTextBox);
            this.Controls.Add(this.ujRendelesDatumTextBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.rendelesFormRemoveRendeles);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.addSzinesCheckBox);
            this.Controls.Add(this.addMuanyagCheckBox);
            this.Controls.Add(this.addTerrakottaCheckBox);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rendelesekFormTermekSumTextBox);
            this.Controls.Add(this.rendelesFormRemoveTermek);
            this.Controls.Add(this.rendelesFormAddTermek);
            this.Controls.Add(this.rendelesekFormListBox3);
            this.Controls.Add(this.rendelesFormAddRendeles);
            this.Controls.Add(this.ujRendelesButton);
            this.Controls.Add(this.rendelesFormDataGridView);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rendelesekFormListBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rendelesekFormListBox);
            this.Controls.Add(this.rendelesekFormEmailTextBox);
            this.Controls.Add(this.rendelesekKilepesButton);
            this.Name = "rendelesekForm";
            this.Text = "rendelesekForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.rendelesekForm_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.rendelesFormDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button rendelesekKilepesButton;
        private System.Windows.Forms.TextBox rendelesekFormEmailTextBox;
        private System.Windows.Forms.ListBox rendelesekFormListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox rendelesekFormListBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView rendelesFormDataGridView;
        private System.Windows.Forms.Button ujRendelesButton;
        private System.Windows.Forms.Button rendelesFormAddRendeles;
        private System.Windows.Forms.ListBox rendelesekFormListBox3;
        private System.Windows.Forms.Button rendelesFormAddTermek;
        private System.Windows.Forms.Button rendelesFormRemoveTermek;
        private System.Windows.Forms.TextBox rendelesekFormTermekSumTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.CheckBox addTerrakottaCheckBox;
        private System.Windows.Forms.CheckBox addMuanyagCheckBox;
        private System.Windows.Forms.CheckBox addSzinesCheckBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Button rendelesFormRemoveRendeles;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label iranyLabel;
        private System.Windows.Forms.Label cimLabel;
        private System.Windows.Forms.Label szallModLabel;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label szamlaCegLabel;
        private System.Windows.Forms.Label szamlaIranyLabel;
        private System.Windows.Forms.Label szamlaCimLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.MaskedTextBox ujRendelesDatumTextBox;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MaskedTextBox addMennyisegTextBox;
    }
}