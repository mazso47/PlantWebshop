﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;                                

namespace JX48WK_Beadando_Webshop
{
    public partial class rendelesekForm : Form
    {
        Noveny_WebshopEntities context = new Noveny_WebshopEntities();
        public rendelesekForm()
        {
            InitializeComponent();

            context.Ugyfel.Load();
            context.Szallitas_mod.Load();
            context.Szallitasi_cim.Load();
            context.Szamlazasi_cim.Load();
            context.Rendeles.Load();
            context.Rendeles_tetel.Load();
            context.Termek.Load();
            context.Termek_noveny.Load();
            context.Noveny_kategoria.Load();
            context.Termek_tarolo.Load();

            FillEmail();
            FillTermek();
            FillRendeles();
            FillRendelesTetel();
            rendelesekFormListBox.DisplayMember = "email";
            rendelesekFormListBox3.DisplayMember = "noveny_nev";
            rendelesekFormListBox3.ValueMember = "noveny_id";
         
            addMennyisegTextBox.Text = 1.ToString();
            ujRendelesDatumTextBox.Text = (DateTime.Now.Date).ToString("d");

                                                            //https://docs.microsoft.com/en-us/dotnet/standard/base-types/standard-date-and-time-format-strings?redirectedfrom=MSDN
                                                            //https://stackoverflow.com/questions/5815932/retrieving-year-and-month-in-yyyymm-format-using-datetime-now     

            ujRendelesDatumTextBox.Mask = "00/00/0000";                                                 
            ujRendelesDatumTextBox.Text = DateTime.Now.Date.ToString("MM/dd/yyyy");
            ujRendelesDatumTextBox.ValidatingType = typeof(System.DateTime);
            addMennyisegTextBox.Mask = "000";
            addMennyisegTextBox.Text = "1";
            addMennyisegTextBox.ValidatingType = typeof(ushort);
            addMennyisegTextBox.HidePromptOnLeave = true;
                                                            //MaskedTextBox validalasra
                                                            //https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.maskedtextbox.validatingtype?view=netcore-3.1
                                                            //https://stackoverflow.com/questions/1459797/hiding-the-promptchar-for-nets-maskedtextbox/9842542
        }

        private void FillEmail()
        {
            rendelesekFormListBox.DataSource = (from x in context.Ugyfel
                                                where x.email.Contains(rendelesekFormEmailTextBox.Text)
                                                select x).ToList();
        }

        private void FillTermek()
        {

            rendelesekFormListBox3.DataSource = (from n in context.Termek_noveny
                                                 where n.noveny_nev.Contains(textBox2.Text)
                                                 select n).ToList();
        }

        private void FillRendeles()
        {
            var ugyfel_id = ((Ugyfel)rendelesekFormListBox.SelectedItem).ugyfel_id;                                         //ha kitorlok mindent es addolni akarok rendelest crashel   FIXED
            var rendelések = from x in context.Rendeles where x.ugyfel_id == ugyfel_id select x;                            // termeknel meg nem, ugyfelnel se jo, nem indul ujra, ha nincs semmi
            rendelesekFormListBox2.DisplayMember = "datum_rendeles";
            rendelesekFormListBox2.DataSource = rendelések.ToList();
        }

        private void FillRendelesTetel()
        {
            if (rendelesekFormListBox2.Items.Count != 0)
            {
                Rendeles rendeles = (Rendeles)rendelesekFormListBox2.SelectedItem;
                var rendeles_id = ((Rendeles)rendelesekFormListBox2.SelectedItem).rendeles_id;
                var rendelésiTételek = from x in context.Rendeles_tetel
                                       where x.rendeles_id == rendeles_id
                                       select new
                                       {
                                           x.tetel_id,
                                           Növény = x.Termek.Termek_noveny.noveny_nev,
                                           Kategória = x.Termek.Termek_noveny.Noveny_kategoria.kat_nev,
                                           Tároló = x.Termek.Termek_tarolo.tarolo_nev,
                                           Ár = x.Termek.Termek_noveny.noveny_ar + x.Termek.Termek_tarolo.tarolo_ar,
                                           Mennyiség = x.mennyiseg
                                       };
                bindingSource1.DataSource = rendelésiTételek.ToList();

                double? termekSum = (from x in context.Rendeles_tetel
                                     where x.rendeles_id == rendeles.rendeles_id
                                     select ((int?)(x.Termek.Termek_noveny.noveny_ar + x.Termek.Termek_tarolo.tarolo_ar) * x.mennyiseg)).Sum() ?? 0;
                rendelesekFormTermekSumTextBox.Text = termekSum.ToString();            //https://stackoverflow.com/questions/16778694/linq-result-if-null-then-zero/16779169

                iranyLabel.Text = rendeles.Szallitasi_cim.iranyitoszam.ToString();
                cimLabel.Text = rendeles.Szallitasi_cim.cim_utca_hazszam;
                szallModLabel.Text = rendeles.Szallitas_mod.mod;
                richTextBox1.Text = rendeles.Szallitasi_cim.megjegyzes;

                var szamlacim_id = rendeles.szamlacim_id;
                var cnt = (from x in context.Szamlazasi_cim
                           where x.szamlacim_id == szamlacim_id
                           select x).Count();
                if (cnt != 0)                                                               //Megnezzuk, hogy a rendeleshez tartozik-e szamlacim
                {
                    szamlaCegLabel.Text = rendeles.Szamlazasi_cim.cegnev;
                    szamlaIranyLabel.Text = rendeles.Szamlazasi_cim.iranyitoszam.ToString();
                    szamlaCimLabel.Text = rendeles.Szamlazasi_cim.cim_utca_hazszam;                    
                }
                else
                {
                    szamlaCegLabel.Text = "Nincs megadva";
                    szamlaIranyLabel.Text = "Nincs megadva";
                    szamlaCimLabel.Text = "Nincs megadva";
                }
            }
        }

        private void rendelesekFormEmailTextBox_TextChanged(object sender, EventArgs e)
        {
            FillEmail();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            FillTermek();
        }

        private void rendelesekFormListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillRendeles();
        }

        private void rendelesekFormListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillRendelesTetel();
        }

        private void ujRendelesButton_Click(object sender, EventArgs e)
        {
            ujRendelesForm urf = new ujRendelesForm();
            DialogResult result = urf.ShowDialog();

            if (result == DialogResult.OK)
            {
                
                Ugyfel ugyfel = new Ugyfel();                                                       //Uj ugyfel felvetele az Ugyfel tablaba
                ugyfel.vezeteknev = urf.ujVnevTextBox.Text;
                ugyfel.keresztnev = urf.ujKnevTextBox.Text;
                ugyfel.email = urf.ujEmailTextBox.Text;
                ugyfel.tel = urf.ujTelTextBox.Text;

                Szallitasi_cim szallcim = new Szallitasi_cim();                                    //Uj szallitasi cim felvetele a Szallitasi_cim tablaba
                szallcim.iranyitoszam = Convert.ToInt32(urf.ujIranyTextBox.Text);
                szallcim.varos = urf.ujVarosTextBox.Text;
                szallcim.cim_utca_hazszam = urf.ujCimTextBox.Text;
                szallcim.megjegyzes = urf.ujMegjTextBox.Text;

                Rendeles rendeles = new Rendeles();                                                 //Uj rendeles felvetele a Rendeles tablaba
                rendeles.ugyfel_id = ugyfel.ugyfel_id;
                if (urf.hazhozCheckBox.Checked) rendeles.szallmod_id = 1;
                if (urf.szemelyesCheckBox.Checked) rendeles.szallmod_id = 2;
                if (urf.csomagPontCheckBox.Checked) rendeles.szallmod_id = 3;
                rendeles.szallcim_id = szallcim.szallcim_id;
                rendeles.datum_rendeles = DateTime.Now.Date;

                if (urf.szamlaCheckBox.Checked)
                {
                    Szamlazasi_cim szamlacim = new Szamlazasi_cim();                                    //Uj szamlazasi cim felvetele a Szamlazasi_cim tablaba, ha van megadva
                    szamlacim.cegnev = urf.szamlaTextBox4.Text;
                    szamlacim.iranyitoszam = Convert.ToInt32(urf.szamlaTextBox1.Text);
                    szamlacim.varos = urf.szamlaTextBox2.Text;
                    szamlacim.cim_utca_hazszam = urf.szamlaTextBox3.Text;
                    rendeles.szamlacim_id = szamlacim.szamlacim_id;
                    context.Szamlazasi_cim.Local.Add(szamlacim);
                }                

                Rendeles_tetel rendelestetel = new Rendeles_tetel();                             //Az ujan felvett rendelesbe az elso rendelesi tetel felvetele a Rendeles_tetel tablaba
                rendelestetel.rendeles_id = rendeles.rendeles_id;
                var kivalasztott = Convert.ToInt32(urf.ujNovenyListBox.SelectedValue);
                var terrakottaChecked = 1;
                var muanyagChecked = 2;
                var szinesChecked = 3;
                if (urf.taroloTerrakottaCheckBox.Checked)
                {
                     rendelestetel.termek_id = 3 * kivalasztott - 2 * terrakottaChecked;            //A megfelelo termek_id-kat a noveny_id es tarolo_id szamokbol kell kihozni
                }
                if (urf.taroloMuanyagCheckBox.Checked)
                {
                    rendelestetel.termek_id = kivalasztott * (muanyagChecked + 1) - 1;
                }
                if (urf.taroloSzinesCheckBox.Checked)
                {
                    rendelestetel.termek_id = kivalasztott * szinesChecked;
                }
                rendelestetel.mennyiseg = Convert.ToInt32(urf.ujTermekMennyiseg.Text);

                context.Ugyfel.Local.Add(ugyfel);
                context.Szallitasi_cim.Local.Add(szallcim);
                context.Rendeles.Local.Add(rendeles);
                context.Rendeles_tetel.Local.Add(rendelestetel);

                try
                {
                    context.SaveChanges();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                FillEmail();
            }
        }

        private void rendelesFormAddRendeles_Click(object sender, EventArgs e)
        {
            if (rendelesekFormListBox.Items.Count != 0)
            {
                if (rendelesekFormListBox2.Items.Count != 0)
                {
                    Rendeles ujrendeles = new Rendeles();
                    var meglevoUgyfel = ((Ugyfel)rendelesekFormListBox.SelectedItem).ugyfel_id;                                 //Uj rendeles felvetele meglevo ugyfelhez
                    ujrendeles.ugyfel_id = meglevoUgyfel;
                    ujrendeles.szallmod_id = ((Rendeles)rendelesekFormListBox2.SelectedItem).szallmod_id;
                    ujrendeles.szamlacim_id = ((Rendeles)rendelesekFormListBox2.SelectedItem).szamlacim_id;
                    ujrendeles.szallcim_id = ((Rendeles)rendelesekFormListBox2.SelectedItem).szallcim_id;
                    ujrendeles.datum_rendeles = Convert.ToDateTime(ujRendelesDatumTextBox.Text);
                    context.Rendeles.Local.Add(ujrendeles);
                }

                try
                {
                    context.SaveChanges();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                FillRendeles();
            }
        }

        private void rendelesFormRemoveRendeles_Click(object sender, EventArgs e)
        {
            if (rendelesekFormListBox2.Items.Count != 0)                                //Ha ures a rendeles lista, ne csinaljon a gomb semmit
            {
                int rid = ((Rendeles)rendelesekFormListBox2.SelectedItem).rendeles_id;          //Megszamoljuk hany rendeles tetel van a kivalasztott rendelesben
                int? cnt = (from x in context.Rendeles_tetel                                
                            where x.rendeles_id == rid
                            select x).Count();
    
                if (rendelesekFormListBox2.Items.Count == 1)                        //Ha mar csak egy rendeles maradt, es azt is torolnenk, toroljuk a hozza tartozo ugyfelt is
                {
                    ugyfelTorles ut = new ugyfelTorles();
                    DialogResult result = ut.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        for (int i = 0; i < cnt; i++)
                        {
                            var torlendo = (from x in context.Rendeles_tetel                //Ha kitorlom a rendelest, a rendeles teteleknek is el kell tunniuk a dgwrol
                                            where x.rendeles_id == rid                     //Szamoljuk meg, hogy az egyes rendelesekhez hany tetel tartozik, majd ennyiszer vegyuk ki az elsot
                                            select x).FirstOrDefault();
                            context.Rendeles_tetel.Remove(torlendo);
                            try
                            {
                                context.SaveChanges();
                            }

                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }

                        int uid = ((Rendeles)rendelesekFormListBox2.SelectedItem).ugyfel_id;                            //Ugyfel torlese
                        var torlendo2 = (from x in context.Ugyfel
                                         where x.ugyfel_id == uid
                                         select x).FirstOrDefault();
                        context.Ugyfel.Remove(torlendo2);

                        var torlendo3 = (from x in context.Rendeles                                 //Rendeles torlese
                                         where x.rendeles_id == rid
                                         select x).FirstOrDefault();
                        context.Rendeles.Remove(torlendo3);
                    }
                }

                else                                                                        //Ha tobb is van, akkor csak a kivalasztottat
                {
                    for (int i = 0; i < cnt; i++)
                    {
                        var torlendo = (from x in context.Rendeles_tetel                //Ha kitorlom a rendelest, a rendeles teteleknek is el kell tunniuk a dgwrol
                                        where x.rendeles_id == rid                     //Szamoljuk meg, hogy az egyes rendelesekhez hany tetel tartozik, majd ennyiszer vegyuk ki az elsot
                                        select x).FirstOrDefault();
                        context.Rendeles_tetel.Remove(torlendo);
                        try
                        {
                            context.SaveChanges();
                        }

                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                    var torlendo3 = (from x in context.Rendeles
                                     where x.rendeles_id == rid
                                     select x).FirstOrDefault();
                    context.Rendeles.Remove(torlendo3);
                }

                try
                {
                    context.SaveChanges();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                FillRendeles();
                FillRendelesTetel();
                FillEmail();                                                                        
            }
        }

        private void rendelesFormAddTermek_Click(object sender, EventArgs e)
        {
            if (!(addMennyisegTextBox.Text == string.Empty))
            {
                Rendeles_tetel rt = new Rendeles_tetel();
                rt.rendeles_id = ((Rendeles)rendelesekFormListBox2.SelectedItem).rendeles_id;                   //Meglevo rendeleshez uj tetelek hozzaadasa
                var addKivalasztott = Convert.ToInt32(rendelesekFormListBox3.SelectedValue);
                var terrakottaChecked = 1;
                var muanyagChecked = 2;
                var szinesChecked = 3;
                if (addTerrakottaCheckBox.Checked)
                {
                    rt.termek_id = 3 * addKivalasztott - 2 * terrakottaChecked;                     //Megfelelo termekkodot itt is ki kell szamolni a noveny_id es a tarolo_id-bol
                }
                if (addMuanyagCheckBox.Checked)
                {
                    rt.termek_id = addKivalasztott * (muanyagChecked + 1) - 1;
                }
                if (addSzinesCheckBox.Checked)
                {
                    rt.termek_id = addKivalasztott * szinesChecked;
                }
                rt.mennyiseg = Convert.ToInt32(addMennyisegTextBox.Text);
                context.Rendeles_tetel.Local.Add(rt);

                try
                {
                    context.SaveChanges();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                FillRendelesTetel();
            }
            else
            {
                uresMennyisegForm umf = new uresMennyisegForm();
                umf.Show();
            }
        }

        private void rendelesFormRemoveTermek_Click(object sender, EventArgs e)
        {
           
            if (rendelesFormDataGridView.Rows.Count != 0)
            {
                dynamic aktualis = bindingSource1.Current;                      //Tetelek torlese a rendelesbol
                int tid = aktualis.tetel_id;
                var torlendo = (from x in context.Rendeles_tetel
                                where x.tetel_id == tid
                                select x).FirstOrDefault();
                context.Rendeles_tetel.Remove(torlendo);
                
                try
                {
                    context.SaveChanges();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                FillRendelesTetel();
            }
        }

        private void addTerrakottaCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            addTerrakottaCheckBox.Checked = true;
            addMuanyagCheckBox.Checked = false;
            addSzinesCheckBox.Checked = false;
        }

        private void addMuanyagCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            addMuanyagCheckBox.Checked = true;
            addTerrakottaCheckBox.Checked = false;            
            addSzinesCheckBox.Checked = false;
        }

        private void addSzinesCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            addSzinesCheckBox.Checked = true;
            addTerrakottaCheckBox.Checked = false;
            addMuanyagCheckBox.Checked = false;
        }

        private void rendelesekKilepesButton_Click(object sender, EventArgs e)
        {
            ujRendelesDatumTextBox.Text = DateTime.Now.Date.ToString("MM/dd/yyyy");                         //Hogy bezarhato legyen az ablak jol megadott datum nelkul is
            this.Close();
        }

        private void rendelesekForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            menuForm mf = new menuForm();
            mf.Show();
        }
     
        private void ujRendelesDatumTextBox_TypeValidationCompleted(object sender, TypeValidationEventArgs e)               //Datum validalasa
        {
            if (!e.IsValidInput)
            {
                toolTip1.ToolTipTitle = "Érvénytelen dátum";
                toolTip1.Show("A megadott dátum nem felel meg a kért dátum formátumnak hh/nn/éééé.", ujRendelesDatumTextBox, 0, 20, 5000);
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
            }
        }
    }
}