﻿namespace JX48WK_Beadando_Webshop
{
    partial class menuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jojoLabel = new System.Windows.Forms.Label();
            this.rendelesekButton = new System.Windows.Forms.Button();
            this.termekekButton = new System.Windows.Forms.Button();
            this.unatkozomButton = new System.Windows.Forms.Button();
            this.kilepesButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // jojoLabel
            // 
            this.jojoLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.jojoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.jojoLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.jojoLabel.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jojoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.jojoLabel.Location = new System.Drawing.Point(0, -1);
            this.jojoLabel.Name = "jojoLabel";
            this.jojoLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jojoLabel.Size = new System.Drawing.Size(400, 27);
            this.jojoLabel.TabIndex = 0;
            this.jojoLabel.Text = "JoJo\'s Füvészkert";
            this.jojoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rendelesekButton
            // 
            this.rendelesekButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.rendelesekButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.rendelesekButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.rendelesekButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.rendelesekButton.FlatAppearance.BorderSize = 2;
            this.rendelesekButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rendelesekButton.Font = new System.Drawing.Font("Constantia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rendelesekButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.rendelesekButton.Location = new System.Drawing.Point(225, 132);
            this.rendelesekButton.Name = "rendelesekButton";
            this.rendelesekButton.Size = new System.Drawing.Size(319, 53);
            this.rendelesekButton.TabIndex = 1;
            this.rendelesekButton.Text = "Rendelések";
            this.rendelesekButton.UseVisualStyleBackColor = false;
            this.rendelesekButton.Click += new System.EventHandler(this.rendelesekButton_Click);
            // 
            // termekekButton
            // 
            this.termekekButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.termekekButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.termekekButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.termekekButton.FlatAppearance.BorderSize = 2;
            this.termekekButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.termekekButton.Font = new System.Drawing.Font("Constantia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termekekButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.termekekButton.Location = new System.Drawing.Point(225, 210);
            this.termekekButton.Name = "termekekButton";
            this.termekekButton.Size = new System.Drawing.Size(319, 53);
            this.termekekButton.TabIndex = 2;
            this.termekekButton.Text = "Termékek";
            this.termekekButton.UseVisualStyleBackColor = false;
            this.termekekButton.Click += new System.EventHandler(this.termekekButton_Click);
            // 
            // unatkozomButton
            // 
            this.unatkozomButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.unatkozomButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.unatkozomButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.unatkozomButton.FlatAppearance.BorderSize = 2;
            this.unatkozomButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.unatkozomButton.Font = new System.Drawing.Font("Constantia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unatkozomButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.unatkozomButton.Location = new System.Drawing.Point(225, 287);
            this.unatkozomButton.Name = "unatkozomButton";
            this.unatkozomButton.Size = new System.Drawing.Size(319, 53);
            this.unatkozomButton.TabIndex = 3;
            this.unatkozomButton.Text = "Unatkozom";
            this.unatkozomButton.UseVisualStyleBackColor = false;
            this.unatkozomButton.Click += new System.EventHandler(this.unatkozomButton_Click);
            // 
            // kilepesButton
            // 
            this.kilepesButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.kilepesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.kilepesButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.kilepesButton.FlatAppearance.BorderSize = 2;
            this.kilepesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kilepesButton.Font = new System.Drawing.Font("Constantia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kilepesButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.kilepesButton.Location = new System.Drawing.Point(225, 386);
            this.kilepesButton.Name = "kilepesButton";
            this.kilepesButton.Size = new System.Drawing.Size(319, 53);
            this.kilepesButton.TabIndex = 4;
            this.kilepesButton.Text = "Kilépés";
            this.kilepesButton.UseVisualStyleBackColor = false;
            this.kilepesButton.Click += new System.EventHandler(this.kilepesButton_Click);
            // 
            // menuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::JX48WK_Beadando_Webshop.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(800, 468);
            this.Controls.Add(this.kilepesButton);
            this.Controls.Add(this.unatkozomButton);
            this.Controls.Add(this.termekekButton);
            this.Controls.Add(this.rendelesekButton);
            this.Controls.Add(this.jojoLabel);
            this.Name = "menuForm";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label jojoLabel;
        private System.Windows.Forms.Button rendelesekButton;
        private System.Windows.Forms.Button termekekButton;
        private System.Windows.Forms.Button unatkozomButton;
        private System.Windows.Forms.Button kilepesButton;
    }
}

