﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JX48WK_Beadando_Webshop
{
    public partial class uresMennyisegForm : Form
    {
        public uresMennyisegForm()
        {
            InitializeComponent();
            label1.Size = new Size(ClientRectangle.Width, 40);
            this.Text = "Üres mennyiség";
            this.ShowIcon = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
