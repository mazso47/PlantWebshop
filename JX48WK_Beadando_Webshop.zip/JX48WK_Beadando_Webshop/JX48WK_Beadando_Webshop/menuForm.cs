﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JX48WK_Beadando_Webshop
{
    public partial class menuForm : Form
    {
        public menuForm()
        {
            InitializeComponent();
            jojoLabel.MinimumSize = new Size(ClientRectangle.Width, 80);
            this.Text = "Jojo's Füvészkert";
            this.ShowIcon = false;
        }

        private void rendelesekButton_Click(object sender, EventArgs e)
        {
            rendelesekForm rendf = new rendelesekForm();
            rendf.Show();
            rendf.Text = "Rendelések";
            rendf.ShowIcon = false;
            this.Hide();
        }
        
        private void termekekButton_Click(object sender, EventArgs e)
        {
            termekekForm termf = new termekekForm();
            termf.Show();
            termf.Text = "Termékek";
            termf.ShowIcon = false;
            this.Hide();
        }

        private void unatkozomButton_Click(object sender, EventArgs e)
        {
            unatkozomForm uf = new unatkozomForm();
            uf.Show();
            uf.Text = "Unatkozom";
            uf.ShowIcon = false;
            this.Hide();
        }

        private void kilepesButton_Click(object sender, EventArgs e)
        {
            exitForm exf = new exitForm();
            exf.Text = "Kilépés";
            exf.ShowIcon = false;
            DialogResult exfResult = exf.ShowDialog();
            

            if (exfResult == DialogResult.OK)
            {
                Application.Exit();
            }
        }
    }
}
