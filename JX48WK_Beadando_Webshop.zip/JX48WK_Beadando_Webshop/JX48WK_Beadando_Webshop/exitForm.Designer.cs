﻿namespace JX48WK_Beadando_Webshop
{
    partial class exitForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitConfirmLabel = new System.Windows.Forms.Label();
            this.exitOkButton = new System.Windows.Forms.Button();
            this.exitCancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // exitConfirmLabel
            // 
            this.exitConfirmLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.exitConfirmLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.exitConfirmLabel.Font = new System.Drawing.Font("Constantia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitConfirmLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.exitConfirmLabel.Location = new System.Drawing.Point(-1, -1);
            this.exitConfirmLabel.Name = "exitConfirmLabel";
            this.exitConfirmLabel.Size = new System.Drawing.Size(211, 23);
            this.exitConfirmLabel.TabIndex = 0;
            this.exitConfirmLabel.Text = "Biztosan ki akarsz lépni?";
            this.exitConfirmLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitOkButton
            // 
            this.exitOkButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.exitOkButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.exitOkButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.exitOkButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.exitOkButton.FlatAppearance.BorderSize = 2;
            this.exitOkButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitOkButton.Font = new System.Drawing.Font("Constantia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitOkButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.exitOkButton.Location = new System.Drawing.Point(33, 83);
            this.exitOkButton.Name = "exitOkButton";
            this.exitOkButton.Size = new System.Drawing.Size(100, 40);
            this.exitOkButton.TabIndex = 1;
            this.exitOkButton.Text = "Igen";
            this.exitOkButton.UseVisualStyleBackColor = false;
            // 
            // exitCancelButton
            // 
            this.exitCancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.exitCancelButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.exitCancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitCancelButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.exitCancelButton.FlatAppearance.BorderSize = 2;
            this.exitCancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitCancelButton.Font = new System.Drawing.Font("Constantia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitCancelButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.exitCancelButton.Location = new System.Drawing.Point(210, 83);
            this.exitCancelButton.Name = "exitCancelButton";
            this.exitCancelButton.Size = new System.Drawing.Size(100, 40);
            this.exitCancelButton.TabIndex = 2;
            this.exitCancelButton.Text = "Mégse";
            this.exitCancelButton.UseVisualStyleBackColor = false;
            // 
            // exitForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(235)))), ((int)(((byte)(168)))));
            this.ClientSize = new System.Drawing.Size(345, 145);
            this.Controls.Add(this.exitCancelButton);
            this.Controls.Add(this.exitOkButton);
            this.Controls.Add(this.exitConfirmLabel);
            this.Name = "exitForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "exitForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label exitConfirmLabel;
        private System.Windows.Forms.Button exitOkButton;
        private System.Windows.Forms.Button exitCancelButton;
    }
}