﻿namespace JX48WK_Beadando_Webshop
{
    partial class ujRendelesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ujVnevTextBox = new System.Windows.Forms.TextBox();
            this.ujKnevTextBox = new System.Windows.Forms.TextBox();
            this.ujEmailTextBox = new System.Windows.Forms.TextBox();
            this.ujTelTextBox = new System.Windows.Forms.TextBox();
            this.ujIranyTextBox = new System.Windows.Forms.TextBox();
            this.ujVarosTextBox = new System.Windows.Forms.TextBox();
            this.ujCimTextBox = new System.Windows.Forms.TextBox();
            this.szamlaCheckBox = new System.Windows.Forms.CheckBox();
            this.ujMegjTextBox = new System.Windows.Forms.RichTextBox();
            this.szamlaTextBox3 = new System.Windows.Forms.TextBox();
            this.szamlaTextBox2 = new System.Windows.Forms.TextBox();
            this.szamlaTextBox1 = new System.Windows.Forms.TextBox();
            this.szamlaLabel3 = new System.Windows.Forms.Label();
            this.szamlaLabel2 = new System.Windows.Forms.Label();
            this.szamlaLabel1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.hazhozCheckBox = new System.Windows.Forms.CheckBox();
            this.csomagPontCheckBox = new System.Windows.Forms.CheckBox();
            this.szemelyesCheckBox = new System.Windows.Forms.CheckBox();
            this.szamlaLabel4 = new System.Windows.Forms.Label();
            this.szamlaTextBox4 = new System.Windows.Forms.TextBox();
            this.ujNovenyListBox = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.taroloTerrakottaCheckBox = new System.Windows.Forms.CheckBox();
            this.taroloMuanyagCheckBox = new System.Windows.Forms.CheckBox();
            this.taroloSzinesCheckBox = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ujTermekMennyiseg = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vezetéknév:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Keresztnév:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "E-mail cím:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Telefonszám:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 164);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Szállítási mód:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 226);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Irányítószám:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Város:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(54, 291);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Cím:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 323);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Megjegyzés:";
            // 
            // ujVnevTextBox
            // 
            this.ujVnevTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujVnevTextBox.Location = new System.Drawing.Point(89, 38);
            this.ujVnevTextBox.Name = "ujVnevTextBox";
            this.ujVnevTextBox.Size = new System.Drawing.Size(172, 20);
            this.ujVnevTextBox.TabIndex = 10;
            this.ujVnevTextBox.TextChanged += new System.EventHandler(this.ujVnevTextBox_TextChanged);
            this.ujVnevTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.ujVnevTextBox_Validating);
            this.ujVnevTextBox.Validated += new System.EventHandler(this.ujVnevTextBox_Validated);
            // 
            // ujKnevTextBox
            // 
            this.ujKnevTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujKnevTextBox.Location = new System.Drawing.Point(89, 68);
            this.ujKnevTextBox.Name = "ujKnevTextBox";
            this.ujKnevTextBox.Size = new System.Drawing.Size(172, 20);
            this.ujKnevTextBox.TabIndex = 11;
            this.ujKnevTextBox.TextChanged += new System.EventHandler(this.ujKnevTextBox_TextChanged);
            this.ujKnevTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.ujKnevTextBox_Validating);
            this.ujKnevTextBox.Validated += new System.EventHandler(this.ujKnevTextBox_Validated);
            // 
            // ujEmailTextBox
            // 
            this.ujEmailTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujEmailTextBox.Location = new System.Drawing.Point(89, 99);
            this.ujEmailTextBox.Name = "ujEmailTextBox";
            this.ujEmailTextBox.Size = new System.Drawing.Size(172, 20);
            this.ujEmailTextBox.TabIndex = 12;
            this.ujEmailTextBox.TextChanged += new System.EventHandler(this.ujEmailTextBox_TextChanged);
            this.ujEmailTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.ujEmailTextBox_Validating);
            this.ujEmailTextBox.Validated += new System.EventHandler(this.ujEmailTextBox_Validated);
            // 
            // ujTelTextBox
            // 
            this.ujTelTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujTelTextBox.Location = new System.Drawing.Point(89, 132);
            this.ujTelTextBox.Name = "ujTelTextBox";
            this.ujTelTextBox.Size = new System.Drawing.Size(172, 20);
            this.ujTelTextBox.TabIndex = 13;
            this.ujTelTextBox.TextChanged += new System.EventHandler(this.ujTelTextBox_TextChanged);
            this.ujTelTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.ujTelTextBox_Validating);
            this.ujTelTextBox.Validated += new System.EventHandler(this.ujTelTextBox_Validated);
            // 
            // ujIranyTextBox
            // 
            this.ujIranyTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujIranyTextBox.Location = new System.Drawing.Point(89, 223);
            this.ujIranyTextBox.Name = "ujIranyTextBox";
            this.ujIranyTextBox.Size = new System.Drawing.Size(172, 20);
            this.ujIranyTextBox.TabIndex = 14;
            this.ujIranyTextBox.TextChanged += new System.EventHandler(this.ujIranyTextBox_TextChanged);
            this.ujIranyTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.ujIranyTextBox_Validating);
            this.ujIranyTextBox.Validated += new System.EventHandler(this.ujIranyTextBox_Validated);
            // 
            // ujVarosTextBox
            // 
            this.ujVarosTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujVarosTextBox.Location = new System.Drawing.Point(89, 255);
            this.ujVarosTextBox.Name = "ujVarosTextBox";
            this.ujVarosTextBox.Size = new System.Drawing.Size(172, 20);
            this.ujVarosTextBox.TabIndex = 15;
            // 
            // ujCimTextBox
            // 
            this.ujCimTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujCimTextBox.Location = new System.Drawing.Point(89, 288);
            this.ujCimTextBox.Name = "ujCimTextBox";
            this.ujCimTextBox.Size = new System.Drawing.Size(172, 20);
            this.ujCimTextBox.TabIndex = 16;
            this.ujCimTextBox.TextChanged += new System.EventHandler(this.ujCimTextBox_TextChanged);
            this.ujCimTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.ujCimTextBox_Validating);
            this.ujCimTextBox.Validated += new System.EventHandler(this.ujCimTextBox_Validated);
            // 
            // szamlaCheckBox
            // 
            this.szamlaCheckBox.AutoSize = true;
            this.szamlaCheckBox.Location = new System.Drawing.Point(89, 503);
            this.szamlaCheckBox.Name = "szamlaCheckBox";
            this.szamlaCheckBox.Size = new System.Drawing.Size(127, 17);
            this.szamlaCheckBox.TabIndex = 18;
            this.szamlaCheckBox.Text = "Eltérő számlázási cím";
            this.szamlaCheckBox.UseVisualStyleBackColor = true;
            this.szamlaCheckBox.CheckedChanged += new System.EventHandler(this.szamlaCheckBox_CheckedChanged);
            // 
            // ujMegjTextBox
            // 
            this.ujMegjTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujMegjTextBox.Location = new System.Drawing.Point(89, 323);
            this.ujMegjTextBox.Name = "ujMegjTextBox";
            this.ujMegjTextBox.Size = new System.Drawing.Size(172, 164);
            this.ujMegjTextBox.TabIndex = 20;
            this.ujMegjTextBox.Text = "";
            // 
            // szamlaTextBox3
            // 
            this.szamlaTextBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.szamlaTextBox3.Location = new System.Drawing.Point(89, 604);
            this.szamlaTextBox3.Name = "szamlaTextBox3";
            this.szamlaTextBox3.Size = new System.Drawing.Size(172, 20);
            this.szamlaTextBox3.TabIndex = 26;
            this.szamlaTextBox3.Visible = false;
            this.szamlaTextBox3.TextChanged += new System.EventHandler(this.szamlaTextBox3_TextChanged);
            this.szamlaTextBox3.Validating += new System.ComponentModel.CancelEventHandler(this.szamlaTextBox3_Validating);
            this.szamlaTextBox3.Validated += new System.EventHandler(this.szamlaTextBox3_Validated);
            // 
            // szamlaTextBox2
            // 
            this.szamlaTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.szamlaTextBox2.Location = new System.Drawing.Point(89, 578);
            this.szamlaTextBox2.Name = "szamlaTextBox2";
            this.szamlaTextBox2.Size = new System.Drawing.Size(172, 20);
            this.szamlaTextBox2.TabIndex = 25;
            this.szamlaTextBox2.Visible = false;
            // 
            // szamlaTextBox1
            // 
            this.szamlaTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.szamlaTextBox1.Location = new System.Drawing.Point(89, 552);
            this.szamlaTextBox1.Name = "szamlaTextBox1";
            this.szamlaTextBox1.Size = new System.Drawing.Size(172, 20);
            this.szamlaTextBox1.TabIndex = 24;
            this.szamlaTextBox1.Visible = false;
            this.szamlaTextBox1.TextChanged += new System.EventHandler(this.szamlaTextBox1_TextChanged);
            this.szamlaTextBox1.Validating += new System.ComponentModel.CancelEventHandler(this.szamlaTextBox1_Validating);
            this.szamlaTextBox1.Validated += new System.EventHandler(this.szamlaTextBox1_Validated);
            // 
            // szamlaLabel3
            // 
            this.szamlaLabel3.AutoSize = true;
            this.szamlaLabel3.Location = new System.Drawing.Point(54, 607);
            this.szamlaLabel3.Name = "szamlaLabel3";
            this.szamlaLabel3.Size = new System.Drawing.Size(29, 13);
            this.szamlaLabel3.TabIndex = 23;
            this.szamlaLabel3.Text = "Cím:";
            this.szamlaLabel3.Visible = false;
            // 
            // szamlaLabel2
            // 
            this.szamlaLabel2.AutoSize = true;
            this.szamlaLabel2.Location = new System.Drawing.Point(46, 578);
            this.szamlaLabel2.Name = "szamlaLabel2";
            this.szamlaLabel2.Size = new System.Drawing.Size(37, 13);
            this.szamlaLabel2.TabIndex = 22;
            this.szamlaLabel2.Text = "Város:";
            this.szamlaLabel2.Visible = false;
            // 
            // szamlaLabel1
            // 
            this.szamlaLabel1.AutoSize = true;
            this.szamlaLabel1.Location = new System.Drawing.Point(16, 555);
            this.szamlaLabel1.Name = "szamlaLabel1";
            this.szamlaLabel1.Size = new System.Drawing.Size(70, 13);
            this.szamlaLabel1.TabIndex = 21;
            this.szamlaLabel1.Text = "Irányítószám:";
            this.szamlaLabel1.Visible = false;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.button1.Location = new System.Drawing.Point(109, 649);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 29);
            this.button1.TabIndex = 27;
            this.button1.Text = "Mentés";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.button2.CausesValidation = false;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.button2.Location = new System.Drawing.Point(332, 649);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 29);
            this.button2.TabIndex = 28;
            this.button2.Text = "Mégse";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // hazhozCheckBox
            // 
            this.hazhozCheckBox.AutoSize = true;
            this.hazhozCheckBox.Checked = true;
            this.hazhozCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.hazhozCheckBox.Location = new System.Drawing.Point(89, 164);
            this.hazhozCheckBox.Name = "hazhozCheckBox";
            this.hazhozCheckBox.Size = new System.Drawing.Size(100, 17);
            this.hazhozCheckBox.TabIndex = 33;
            this.hazhozCheckBox.Text = "Házhozszállítás";
            this.hazhozCheckBox.UseVisualStyleBackColor = true;
            this.hazhozCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hazhozCheckBox_MouseClick);
            // 
            // csomagPontCheckBox
            // 
            this.csomagPontCheckBox.AutoSize = true;
            this.csomagPontCheckBox.Location = new System.Drawing.Point(89, 182);
            this.csomagPontCheckBox.Name = "csomagPontCheckBox";
            this.csomagPontCheckBox.Size = new System.Drawing.Size(85, 17);
            this.csomagPontCheckBox.TabIndex = 34;
            this.csomagPontCheckBox.Text = "Csomagpont";
            this.csomagPontCheckBox.UseVisualStyleBackColor = true;
            this.csomagPontCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.csomagPontCheckBox_MouseClick);
            // 
            // szemelyesCheckBox
            // 
            this.szemelyesCheckBox.AutoSize = true;
            this.szemelyesCheckBox.Location = new System.Drawing.Point(89, 200);
            this.szemelyesCheckBox.Name = "szemelyesCheckBox";
            this.szemelyesCheckBox.Size = new System.Drawing.Size(111, 17);
            this.szemelyesCheckBox.TabIndex = 35;
            this.szemelyesCheckBox.Text = "Személyes átvétel";
            this.szemelyesCheckBox.UseVisualStyleBackColor = true;
            this.szemelyesCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.szemelyesCheckBox_MouseClick);
            // 
            // szamlaLabel4
            // 
            this.szamlaLabel4.AutoSize = true;
            this.szamlaLabel4.Location = new System.Drawing.Point(36, 529);
            this.szamlaLabel4.Name = "szamlaLabel4";
            this.szamlaLabel4.Size = new System.Drawing.Size(47, 13);
            this.szamlaLabel4.TabIndex = 36;
            this.szamlaLabel4.Text = "Cégnév:";
            this.szamlaLabel4.Visible = false;
            // 
            // szamlaTextBox4
            // 
            this.szamlaTextBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.szamlaTextBox4.Location = new System.Drawing.Point(89, 526);
            this.szamlaTextBox4.Name = "szamlaTextBox4";
            this.szamlaTextBox4.Size = new System.Drawing.Size(172, 20);
            this.szamlaTextBox4.TabIndex = 37;
            this.szamlaTextBox4.Visible = false;
            this.szamlaTextBox4.TextChanged += new System.EventHandler(this.szamlaTextBox4_TextChanged);
            this.szamlaTextBox4.Validating += new System.ComponentModel.CancelEventHandler(this.szamlaTextBox4_Validating);
            this.szamlaTextBox4.Validated += new System.EventHandler(this.szamlaTextBox4_Validated);
            // 
            // ujNovenyListBox
            // 
            this.ujNovenyListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ujNovenyListBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.ujNovenyListBox.FormattingEnabled = true;
            this.ujNovenyListBox.Location = new System.Drawing.Point(302, 54);
            this.ujNovenyListBox.Name = "ujNovenyListBox";
            this.ujNovenyListBox.Size = new System.Drawing.Size(172, 433);
            this.ujNovenyListBox.TabIndex = 38;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(299, 38);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(108, 13);
            this.label13.TabIndex = 39;
            this.label13.Text = "Növény kiválasztása:";
            // 
            // taroloTerrakottaCheckBox
            // 
            this.taroloTerrakottaCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.taroloTerrakottaCheckBox.AutoSize = true;
            this.taroloTerrakottaCheckBox.Checked = true;
            this.taroloTerrakottaCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.taroloTerrakottaCheckBox.Location = new System.Drawing.Point(302, 511);
            this.taroloTerrakottaCheckBox.Name = "taroloTerrakottaCheckBox";
            this.taroloTerrakottaCheckBox.Size = new System.Drawing.Size(75, 17);
            this.taroloTerrakottaCheckBox.TabIndex = 40;
            this.taroloTerrakottaCheckBox.Text = "Terrakotta";
            this.taroloTerrakottaCheckBox.UseVisualStyleBackColor = true;
            this.taroloTerrakottaCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.taroloTerrakottaCheckBox_MouseClick);
            // 
            // taroloMuanyagCheckBox
            // 
            this.taroloMuanyagCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.taroloMuanyagCheckBox.AutoSize = true;
            this.taroloMuanyagCheckBox.Location = new System.Drawing.Point(302, 534);
            this.taroloMuanyagCheckBox.Name = "taroloMuanyagCheckBox";
            this.taroloMuanyagCheckBox.Size = new System.Drawing.Size(70, 17);
            this.taroloMuanyagCheckBox.TabIndex = 41;
            this.taroloMuanyagCheckBox.Text = "Műanyag";
            this.taroloMuanyagCheckBox.UseVisualStyleBackColor = true;
            this.taroloMuanyagCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.taroloMuanyagCheckBox_MouseClick);
            // 
            // taroloSzinesCheckBox
            // 
            this.taroloSzinesCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.taroloSzinesCheckBox.AutoSize = true;
            this.taroloSzinesCheckBox.Location = new System.Drawing.Point(302, 557);
            this.taroloSzinesCheckBox.Name = "taroloSzinesCheckBox";
            this.taroloSzinesCheckBox.Size = new System.Drawing.Size(91, 17);
            this.taroloSzinesCheckBox.TabIndex = 42;
            this.taroloSzinesCheckBox.Text = "Színes kaspó";
            this.taroloSzinesCheckBox.UseVisualStyleBackColor = true;
            this.taroloSzinesCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.taroloSzinesCheckBox_MouseClick);
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(299, 495);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 43;
            this.label9.Text = "Tároló:";
            // 
            // ujTermekMennyiseg
            // 
            this.ujTermekMennyiseg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ujTermekMennyiseg.Location = new System.Drawing.Point(302, 602);
            this.ujTermekMennyiseg.Name = "ujTermekMennyiseg";
            this.ujTermekMennyiseg.Size = new System.Drawing.Size(58, 20);
            this.ujTermekMennyiseg.TabIndex = 44;
            this.ujTermekMennyiseg.TextChanged += new System.EventHandler(this.ujTermekMennyiseg_TextChanged);
            this.ujTermekMennyiseg.Validating += new System.ComponentModel.CancelEventHandler(this.ujTermekMennyiseg_Validating);
            this.ujTermekMennyiseg.Validated += new System.EventHandler(this.ujTermekMennyiseg_Validated);
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(299, 586);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 13);
            this.label11.TabIndex = 45;
            this.label11.Text = "Mennyiség:";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.label12.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.label12.Location = new System.Drawing.Point(0, -1);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 23);
            this.label12.TabIndex = 46;
            this.label12.Text = "Új rendelés felvétele";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // ujRendelesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(235)))), ((int)(((byte)(168)))));
            this.ClientSize = new System.Drawing.Size(500, 682);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.ujTermekMennyiseg);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.taroloSzinesCheckBox);
            this.Controls.Add(this.taroloMuanyagCheckBox);
            this.Controls.Add(this.taroloTerrakottaCheckBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.ujNovenyListBox);
            this.Controls.Add(this.szamlaTextBox4);
            this.Controls.Add(this.szamlaLabel4);
            this.Controls.Add(this.szemelyesCheckBox);
            this.Controls.Add(this.csomagPontCheckBox);
            this.Controls.Add(this.hazhozCheckBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.szamlaTextBox3);
            this.Controls.Add(this.szamlaTextBox2);
            this.Controls.Add(this.szamlaTextBox1);
            this.Controls.Add(this.szamlaLabel3);
            this.Controls.Add(this.szamlaLabel2);
            this.Controls.Add(this.szamlaLabel1);
            this.Controls.Add(this.ujMegjTextBox);
            this.Controls.Add(this.szamlaCheckBox);
            this.Controls.Add(this.ujCimTextBox);
            this.Controls.Add(this.ujVarosTextBox);
            this.Controls.Add(this.ujIranyTextBox);
            this.Controls.Add(this.ujTelTextBox);
            this.Controls.Add(this.ujEmailTextBox);
            this.Controls.Add(this.ujKnevTextBox);
            this.Controls.Add(this.ujVnevTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ujRendelesForm";
            this.Text = "ujRendelesForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label szamlaLabel3;
        private System.Windows.Forms.Label szamlaLabel2;
        private System.Windows.Forms.Label szamlaLabel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.TextBox ujVnevTextBox;
        public System.Windows.Forms.TextBox ujKnevTextBox;
        public System.Windows.Forms.TextBox ujEmailTextBox;
        public System.Windows.Forms.TextBox ujTelTextBox;
        public System.Windows.Forms.TextBox ujIranyTextBox;
        public System.Windows.Forms.TextBox ujVarosTextBox;
        public System.Windows.Forms.TextBox ujCimTextBox;
        public System.Windows.Forms.CheckBox szamlaCheckBox;
        public System.Windows.Forms.RichTextBox ujMegjTextBox;
        public System.Windows.Forms.TextBox szamlaTextBox3;
        public System.Windows.Forms.TextBox szamlaTextBox2;
        public System.Windows.Forms.TextBox szamlaTextBox1;
        private System.Windows.Forms.Label szamlaLabel4;
        public System.Windows.Forms.TextBox szamlaTextBox4;
        public System.Windows.Forms.CheckBox hazhozCheckBox;
        public System.Windows.Forms.CheckBox csomagPontCheckBox;
        public System.Windows.Forms.CheckBox szemelyesCheckBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.ListBox ujNovenyListBox;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox ujTermekMennyiseg;
        public System.Windows.Forms.CheckBox taroloTerrakottaCheckBox;
        public System.Windows.Forms.CheckBox taroloMuanyagCheckBox;
        public System.Windows.Forms.CheckBox taroloSzinesCheckBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}