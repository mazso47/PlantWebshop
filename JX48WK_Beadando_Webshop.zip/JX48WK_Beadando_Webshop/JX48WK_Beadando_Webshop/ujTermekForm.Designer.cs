﻿namespace JX48WK_Beadando_Webshop
{
    partial class ujTermekForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ujTermekNev = new System.Windows.Forms.TextBox();
            this.ujTermekLatin = new System.Windows.Forms.TextBox();
            this.ujTermekAr = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.succCheckBox = new System.Windows.Forms.CheckBox();
            this.araCheckBox = new System.Windows.Forms.CheckBox();
            this.broCheckBox = new System.Windows.Forms.CheckBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.novenykategoriaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenykategoriaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // ujTermekNev
            // 
            this.ujTermekNev.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujTermekNev.Location = new System.Drawing.Point(86, 34);
            this.ujTermekNev.Name = "ujTermekNev";
            this.ujTermekNev.Size = new System.Drawing.Size(100, 20);
            this.ujTermekNev.TabIndex = 0;
            this.ujTermekNev.TextChanged += new System.EventHandler(this.ujTermekNev_TextChanged);
            this.ujTermekNev.Validating += new System.ComponentModel.CancelEventHandler(this.ujTermekNev_Validating);
            this.ujTermekNev.Validated += new System.EventHandler(this.ujTermekNev_Validated);
            // 
            // ujTermekLatin
            // 
            this.ujTermekLatin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujTermekLatin.Location = new System.Drawing.Point(86, 60);
            this.ujTermekLatin.Name = "ujTermekLatin";
            this.ujTermekLatin.Size = new System.Drawing.Size(100, 20);
            this.ujTermekLatin.TabIndex = 1;
            this.ujTermekLatin.TextChanged += new System.EventHandler(this.ujTermekLatin_TextChanged);
            this.ujTermekLatin.Validating += new System.ComponentModel.CancelEventHandler(this.ujTermekLatin_Validating);
            this.ujTermekLatin.Validated += new System.EventHandler(this.ujTermekLatin_Validated);
            // 
            // ujTermekAr
            // 
            this.ujTermekAr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ujTermekAr.Location = new System.Drawing.Point(86, 91);
            this.ujTermekAr.Name = "ujTermekAr";
            this.ujTermekAr.Size = new System.Drawing.Size(100, 20);
            this.ujTermekAr.TabIndex = 2;
            this.ujTermekAr.TextChanged += new System.EventHandler(this.ujTermekAr_TextChanged);
            this.ujTermekAr.Validating += new System.ComponentModel.CancelEventHandler(this.ujTermekAr_Validating);
            this.ujTermekAr.Validated += new System.EventHandler(this.ujTermekAr_Validated);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Növény név:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Latin név:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(59, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Ár:";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.label4.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.label4.Location = new System.Drawing.Point(0, -1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Új növény felvétele";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Kategória:";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.button1.Location = new System.Drawing.Point(28, 195);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 27);
            this.button1.TabIndex = 13;
            this.button1.Text = "Hozzáad";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(95)))), ((int)(((byte)(10)))));
            this.button2.CausesValidation = false;
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Constantia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(243)))), ((int)(((byte)(207)))));
            this.button2.Location = new System.Drawing.Point(139, 195);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 27);
            this.button2.TabIndex = 14;
            this.button2.Text = "Mégse";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // succCheckBox
            // 
            this.succCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.succCheckBox.AutoSize = true;
            this.succCheckBox.Checked = true;
            this.succCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.succCheckBox.Location = new System.Drawing.Point(86, 117);
            this.succCheckBox.Name = "succCheckBox";
            this.succCheckBox.Size = new System.Drawing.Size(79, 17);
            this.succCheckBox.TabIndex = 15;
            this.succCheckBox.Text = "Succulents";
            this.succCheckBox.UseVisualStyleBackColor = true;
            this.succCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.succCheckBox_MouseClick);
            // 
            // araCheckBox
            // 
            this.araCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.araCheckBox.AutoSize = true;
            this.araCheckBox.Location = new System.Drawing.Point(86, 140);
            this.araCheckBox.Name = "araCheckBox";
            this.araCheckBox.Size = new System.Drawing.Size(66, 17);
            this.araCheckBox.TabIndex = 16;
            this.araCheckBox.Text = "Araceae";
            this.araCheckBox.UseVisualStyleBackColor = true;
            this.araCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.araCheckBox_MouseClick);
            // 
            // broCheckBox
            // 
            this.broCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.broCheckBox.AutoSize = true;
            this.broCheckBox.Location = new System.Drawing.Point(86, 162);
            this.broCheckBox.Name = "broCheckBox";
            this.broCheckBox.Size = new System.Drawing.Size(90, 17);
            this.broCheckBox.TabIndex = 17;
            this.broCheckBox.Text = "Bromeliaceae";
            this.broCheckBox.UseVisualStyleBackColor = true;
            this.broCheckBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.broCheckBox_MouseClick);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // novenykategoriaBindingSource
            // 
            this.novenykategoriaBindingSource.DataSource = typeof(JX48WK_Beadando_Webshop.Noveny_kategoria);
            // 
            // ujTermekForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(235)))), ((int)(((byte)(168)))));
            this.ClientSize = new System.Drawing.Size(240, 234);
            this.Controls.Add(this.broCheckBox);
            this.Controls.Add(this.araCheckBox);
            this.Controls.Add(this.succCheckBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ujTermekAr);
            this.Controls.Add(this.ujTermekLatin);
            this.Controls.Add(this.ujTermekNev);
            this.Name = "ujTermekForm";
            this.Text = "ujTermekForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.novenykategoriaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.TextBox ujTermekNev;
        public System.Windows.Forms.TextBox ujTermekLatin;
        public System.Windows.Forms.TextBox ujTermekAr;
        private System.Windows.Forms.BindingSource novenykategoriaBindingSource;
        public System.Windows.Forms.CheckBox succCheckBox;
        public System.Windows.Forms.CheckBox araCheckBox;
        public System.Windows.Forms.CheckBox broCheckBox;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}