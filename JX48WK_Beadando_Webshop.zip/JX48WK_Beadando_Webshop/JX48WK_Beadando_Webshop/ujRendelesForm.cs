﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JX48WK_Beadando_Webshop
{
    public partial class ujRendelesForm : Form
    {
        Noveny_WebshopEntities context = new Noveny_WebshopEntities();
        public ujRendelesForm()
        {
            InitializeComponent();
            ujNovenyListBox.DataSource = context.Termek_noveny.ToList();
            ujNovenyListBox.DisplayMember = "noveny_nev";
            ujNovenyListBox.ValueMember = "noveny_id";

            ujTermekMennyiseg.Text = 1.ToString();

            label12.Size = new Size(ClientRectangle.Width, 30);

            this.Text = "Új rendelés felvétele";
            this.ShowIcon = false;
        }    
           
        private void hazhozCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            hazhozCheckBox.Checked = true;

            szemelyesCheckBox.Checked = false;
            csomagPontCheckBox.Checked = false;
        }

        private void csomagPontCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            csomagPontCheckBox.Checked = true;

            hazhozCheckBox.Checked = false;
            szemelyesCheckBox.Checked = false;
        }

        private void szemelyesCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            szemelyesCheckBox.Checked = true;

            hazhozCheckBox.Checked = false;
            csomagPontCheckBox.Checked = false;            
        }

        private void szamlaCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (szamlaLabel1.Visible == false)
            {
                szamlaLabel1.Visible = true;
                szamlaLabel2.Visible = true;
                szamlaLabel3.Visible = true;
                szamlaLabel4.Visible = true;
                szamlaTextBox1.Visible = true;
                szamlaTextBox2.Visible = true;
                szamlaTextBox3.Visible = true;
                szamlaTextBox4.Visible = true;
            }

            else
            {
                szamlaLabel1.Visible = false;
                szamlaLabel2.Visible = false;
                szamlaLabel3.Visible = false;
                szamlaLabel4.Visible = false;
                szamlaTextBox1.Visible = false;
                szamlaTextBox2.Visible = false;
                szamlaTextBox3.Visible = false;
                szamlaTextBox4.Visible = false;
            }
        }



        private void taroloTerrakottaCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            taroloTerrakottaCheckBox.Checked = true;
            taroloMuanyagCheckBox.Checked = false;
            taroloSzinesCheckBox.Checked = false;
        }

        private void taroloMuanyagCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            taroloMuanyagCheckBox.Checked = true;
            taroloTerrakottaCheckBox.Checked = false;
            taroloSzinesCheckBox.Checked = false;
        }

        private void taroloSzinesCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            taroloSzinesCheckBox.Checked = true;
            taroloTerrakottaCheckBox.Checked = false;
            taroloMuanyagCheckBox.Checked = false;
        }
   

        private bool ValidNemUres(string név)
        {
            return !string.IsNullOrEmpty(név);
        }
        private bool ValidEmail(string email)
        {
            Regex r = new Regex(@"(^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$)");
            return r.IsMatch(email);
        }
        private bool ValidTel(string tel)
        {
            Regex r = new Regex(@"^(\+36|06)(-|/)[0-9]{1,2}-[0-9]{3}-?[0-9]{3,4}$");
            return r.IsMatch(tel);
        }
        private bool ValidIrany(string irany)
        {
            Regex r = new Regex(@"^[0-9]{4}$");
            return r.IsMatch(irany);
        }
        private bool ValidMennyiseg(string mennyiseg)
        {
            Regex r = new Regex(@"^[0-9]{1,3}$");
            return r.IsMatch(mennyiseg);
        }


        private void ujVnevTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidNemUres(ujVnevTextBox.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujVnevTextBox, "A név nem lehet üres");
            }
        }

        private void ujKnevTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidNemUres(ujKnevTextBox.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujKnevTextBox, "A név nem lehet üres");
            }
        }

        private void ujEmailTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidEmail(ujEmailTextBox.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujEmailTextBox, "Megfelelő e-mail címet adj meg!");
            }
        }

        private void ujTelTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidTel(ujTelTextBox.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujTelTextBox, "Megfelelő telefonszámot adj meg!(pl: 06/20-444-777)");
            }
        }

        private void ujIranyTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidIrany(ujIranyTextBox.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujIranyTextBox, "Megfelelő irányítószámot adj meg! (0000)");
            }
        }

        private void ujCimTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidNemUres(ujCimTextBox.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujCimTextBox, "A cím nem lehet üres");
            }
        }

        private void szamlaTextBox4_Validating(object sender, CancelEventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                if (!ValidNemUres(szamlaTextBox4.Text))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(szamlaTextBox4, "A cégnév nem lehet üres");
                }
            }
        }

        private void szamlaTextBox1_Validating(object sender, CancelEventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                if (!ValidIrany(szamlaTextBox1.Text))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(szamlaTextBox1, "Megfelelő irányítószámot adj meg! (0000)");
                }
            }
        }

        private void szamlaTextBox3_Validating(object sender, CancelEventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                if (!ValidNemUres(szamlaTextBox3.Text))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(szamlaTextBox3, "A cím nem lehet üres");
                }
            }
        }
        private void ujTermekMennyiseg_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidMennyiseg(ujTermekMennyiseg.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujTermekMennyiseg, "0-999 között add meg");
            }
        }


        private void ujVnevTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujVnevTextBox, "");
        }

        private void ujKnevTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujKnevTextBox, "");
        }

        private void ujEmailTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujEmailTextBox, "");
        }
        private void ujTelTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujTelTextBox, "");
        }
        private void ujIranyTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujIranyTextBox, "");
        }
        private void ujCimTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujCimTextBox, "");
        }
        private void szamlaTextBox4_Validated(object sender, EventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                errorProvider1.SetError(szamlaTextBox4, "");
            }
        }
        private void szamlaTextBox1_Validated(object sender, EventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                errorProvider1.SetError(szamlaTextBox1, "");
            }
        }
        private void szamlaTextBox3_Validated(object sender, EventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                errorProvider1.SetError(szamlaTextBox3, "");
            }
        }
        private void ujTermekMennyiseg_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujTermekMennyiseg, "");
        }


        private void ujVnevTextBox_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void ujKnevTextBox_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void ujEmailTextBox_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void ujTelTextBox_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void ujIranyTextBox_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void ujCimTextBox_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void szamlaTextBox4_TextChanged(object sender, EventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                this.Validate();
            }
        }

        private void szamlaTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                this.Validate();
            }
        }

        private void szamlaTextBox3_TextChanged(object sender, EventArgs e)
        {
            if (szamlaCheckBox.Checked == true)
            {
                this.Validate();
            }
        }

        private void ujTermekMennyiseg_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }
    }
}
