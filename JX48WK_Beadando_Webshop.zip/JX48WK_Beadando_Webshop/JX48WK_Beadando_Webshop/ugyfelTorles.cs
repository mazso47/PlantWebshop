﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JX48WK_Beadando_Webshop
{
    public partial class ugyfelTorles : Form
    {
        public ugyfelTorles()
        {
            InitializeComponent();
            label1.Size = new Size(ClientRectangle.Width, 40);
            this.Text = "Ügyfél törlése";
            this.ShowIcon = false;
        }
    }
}
