﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JX48WK_Beadando_Webshop
{
    public partial class ujTermekForm : Form
    {
        public ujTermekForm()
        {
            InitializeComponent();
            label4.Size = new Size(ClientRectangle.Width, 30);
            this.Text = "Új termék felvétele";
            this.ShowIcon = false;
        }

        private void succCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            succCheckBox.Checked = true;
            araCheckBox.Checked = false;
            broCheckBox.Checked = false;
        }

        private void araCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            araCheckBox.Checked = true;
            succCheckBox.Checked = false;
            broCheckBox.Checked = false;
        }

        private void broCheckBox_MouseClick(object sender, MouseEventArgs e)
        {
            broCheckBox.Checked = true;
            succCheckBox.Checked = false;
            araCheckBox.Checked = false;            
        }
      
        private bool ValidNev(string név)
        {
            return !string.IsNullOrEmpty(név);
        }

        private bool ValidAr(string ar)
        {
            Regex r = new Regex("^[0-9]+$");
            return r.IsMatch(ar);
        }

        private void ujTermekNev_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidNev(ujTermekNev.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujTermekNev, "A növénynév nem lehet üres");
            }
        }
      
        private void ujTermekLatin_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidNev(ujTermekLatin.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujTermekLatin, "A latin név nem lehet üres");
            }
        }

        private void ujTermekAr_Validating(object sender, CancelEventArgs e)
        {
            if (!ValidAr(ujTermekAr.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(ujTermekAr, "Az árnak egész számnak kell lennie");
            }
        }

        private void ujTermekNev_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujTermekNev, "");
        }
        private void ujTermekLatin_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujTermekLatin, "");
        }

        private void ujTermekAr_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(ujTermekAr, "");
        }


        private void ujTermekNev_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void ujTermekLatin_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }

        private void ujTermekAr_TextChanged(object sender, EventArgs e)
        {
            this.Validate();
        }
    }
}
