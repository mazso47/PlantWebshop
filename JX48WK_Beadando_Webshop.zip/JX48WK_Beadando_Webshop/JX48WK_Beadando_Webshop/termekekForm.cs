﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JX48WK_Beadando_Webshop
{
    public partial class termekekForm : Form
    {
        Noveny_WebshopEntities context = new Noveny_WebshopEntities();
        public termekekForm()
        {
            InitializeComponent();
            context.Termek_noveny.Load();
            context.Noveny_kategoria.Load();
            context.Termek.Load();

            termek_novenyBindingSource.DataSource = context.Termek_noveny.Local;
            novenykategoriaBindingSource.DataSource = context.Noveny_kategoria.Local;
            termekBindingSource.DataSource = context.Termek.Local;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ujTermekForm utf = new ujTermekForm();
            DialogResult result = utf.ShowDialog();

            if (result == DialogResult.OK)
            {
                Termek_noveny noveny = new Termek_noveny();                                                     //Uj noveny felvetele a Termek_noveny tablaba
                noveny.noveny_nev = utf.ujTermekNev.Text;
                noveny.noveny_latin = utf.ujTermekLatin.Text;
                noveny.noveny_ar = Convert.ToInt32(utf.ujTermekAr.Text);
                if (utf.succCheckBox.Checked)
                {
                    noveny.kat_id = 1;
                }
                if (utf.araCheckBox.Checked)
                {
                    noveny.kat_id = 2;
                }
                if (utf.broCheckBox.Checked)
                {
                    noveny.kat_id = 3;
                }

                Termek termek1= new Termek();                                                                   //Az uj noveny felvetele a Termek tablaba, kulonbozo tarolokkal
                termek1.noveny_id = noveny.noveny_id;
                termek1.tarolo_id = 1;

                Termek termek2= new Termek();
                termek2.noveny_id = noveny.noveny_id;
                termek2.tarolo_id = 2;

                Termek termek3 = new Termek();
                termek3.noveny_id = noveny.noveny_id;
                termek3.tarolo_id = 3;

                termek_novenyBindingSource.Add(noveny);
                termekBindingSource.Add(termek1);
                termekBindingSource.Add(termek2);
                termekBindingSource.Add(termek3);

                try
                {
                    context.SaveChanges();
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }

        }

        private void termekFormExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void termekekForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            menuForm mf = new menuForm();
            mf.Show();
        }   
    }
}
